﻿function subroomselect(value, viaid) {
    location.href = "view.php?id="+viaid+"&subroomid="+value;

}
