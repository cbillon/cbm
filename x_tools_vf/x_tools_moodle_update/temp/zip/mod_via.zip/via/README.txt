Version 2024030602

/* for more information on the version please see mod/via/version.php */
/* This plugin requires Via 8.7 or greater */


Procedure for a NEW installation of this plugin :
*********************************************************************

1 - Copy the Via folder into the mod folder of your moodle.

2 - You will need to contact SVIeSolutions (https://sviesolutions.com/) for USA/Canada or Classilio (https://www.classilio.com) for Europe for the following access codes.
    - API's URL
    - Via ID (CieID)
    - Via API ID (ApiID)
    - You can test the connexion + validate that you are connected to the correct version of Via

    - Moodle admin ID
    - You can test the key

    As added security you will need to provide us with your IP address.
    This will be validated along with the IDs provided.

3 - For invoicing and statistics purposes you may create categories in Via and make them available in Moodle.
    Note these need to be created in Via to be available.
    The moodle administrator must check the ckeckbox in the settings page.
    He may also select a default category.
