moodle-mod_flashcard
====================

A module providing a memoizing helper activity using Leitner model

2017022000 : Add models per instance selection.

2019011000 : Normailse the flashcard tasks.

2019121100 : Fix the completion rules