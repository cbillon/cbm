<?php
$string['pluginname'] = 'Responses report';
$string['privacy:metadata'] = 'The responses report module does not store any personal data.';
