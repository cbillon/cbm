<?php
$string['pluginname'] = 'Click trail report';
$string['privacy:metadata'] = 'The click trail report module does not store any personal data.';
