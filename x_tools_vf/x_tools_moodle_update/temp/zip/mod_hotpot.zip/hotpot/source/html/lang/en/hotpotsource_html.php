<?php
$string['pluginname'] = 'HTML source files';
$string['privacy:metadata'] = 'The HTML source files module does not store any personal data.';
