<?php
$string['pluginname'] = 'Hot Potatoes source files';
$string['privacy:metadata'] = 'The hot Potatoes source files module does not store any personal data.';
