<?php
$string['pluginname'] = 'Qedoc output formats';
$string['privacy:metadata'] = 'The Qedoc output formats module does not store any personal data.';
