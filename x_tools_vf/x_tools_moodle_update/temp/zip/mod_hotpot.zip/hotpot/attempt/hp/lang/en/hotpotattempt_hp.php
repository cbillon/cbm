<?php
$string['pluginname'] = 'Hot Potatoes output formats';
$string['privacy:metadata'] = 'The Hot Potatoes output formats module does not store any personal data.';
