Dynamic behaviour : 

This type has no local AMD, but uses the customlabel general AMD toggle model, bases on customctl-<id> custom-<id> id tagging.